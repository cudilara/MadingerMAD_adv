//
//  Restaurants.swift
//  midtermMadinger
//
//  Created by Dilara R Madinger on 3/20/18.
//  Copyright © 2018 Dilara R Madinger. All rights reserved.
//

import Foundation

struct Restaurants: Decodable{
    let name: String
    let url: String
}
