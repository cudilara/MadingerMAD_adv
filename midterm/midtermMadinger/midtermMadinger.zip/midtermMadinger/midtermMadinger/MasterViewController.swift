//
//  MasterViewController.swift
//  midtermMadinger
//
//  Created by Dilara R Madinger on 3/20/18.
//  Copyright © 2018 Dilara R Madinger. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController {

    var detailViewController: DetailViewController? = nil
    var restaurants = [Restaurants]()
    var words = [String]()
    var searchController : UISearchController!


    override func viewDidLoad() {
        super.viewDidLoad()
        loadjson()
        // If time, come back to this.
        words = ["Luciles", "REincon Argentina", "Backcountry Pizza", "West End Tavern"]
        let resultsController = SearchResultsController()
        resultsController.allwords = words
        searchController = UISearchController(searchResultsController: resultsController)
        
        searchController.searchBar.placeholder = "Enter a search word"
        searchController.searchBar.sizeToFit()
        tableView.tableHeaderView = searchController.searchBar
        searchController.searchResultsUpdater = resultsController
        
//        self.navigationItem.rightBarButtonItem=self.editButtonItem
    }

    @IBAction func unwindSegue(_ segue:UIStoryboardSegue){
//        if segue.identifier=="doneSegue"{
//            let source = segue.source as! AddRestaurantViewController
//            if((source.addedRest.isEmpty) == false){
//                restaurants.append(source.addedRest)
//                tableView.reloadData()
//
//            }
//        }
    }
    
    func loadjson(){
        let urlPath = "https://creative.colorado.edu/~apierce/samples/data/restaurants.json"
        guard let url = URL(string: urlPath)
            else {
                print("url error")
                return
        }
        
        let session = URLSession.shared.dataTask(with: url, completionHandler: {(data, response, error) in
            let httpResponse = response as! HTTPURLResponse
            let statusCode = httpResponse.statusCode
            print(statusCode)
            guard statusCode == 200
                else {
                    print("file download error")
                    return
            }
            //download successful
            print("download complete")
            DispatchQueue.main.async {self.parsejson(data!)}
        })
        //must call resume to run session
        session.resume()
    }
    
    func parsejson(_ data: Data){
        do {
            // get json data
            let json = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! [[String:Any]]
            //get all results
//            let allresults = json["results"] as! [[String:Any]]
//            //add results to objects
            for result in json {
                //check that data exists
                guard let newname = result["name"]! as? String,
                    let newurl = result["url"]!as? String
                    else {
                        continue
                }
                //create new object
                let newrestaurant = Restaurants(name: newname, url: newurl)
                //add object to array
                self.restaurants.append(newrestaurant)
            }
            //handle thrown error
        } catch {
            print("Error with JSON: \(error)")
            return
        }
        //reload the table data after the json data has been downloaded
        tableView.reloadData()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.clearsSelectionOnViewWillAppear = self.splitViewController!.isCollapsed
        super.viewWillAppear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let restnt = restaurants[indexPath.row]
                let name = restnt.name
                let url = restnt.url
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
//                switch name{
//                case "Luciles":
//                    controller.detailItem = url
//                default:
//                    controller.detailItem = "https://en.wikipedia.org/wiki/Star_Wars"
//                }
                controller.title = name
                controller.detailItem = url
                controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }

    // MARK: - Table View

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurants.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let restaurant = restaurants[indexPath.row]
        cell.textLabel!.text = restaurant.name
        return cell
    }
    
//    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
//        return true
//    }
}

