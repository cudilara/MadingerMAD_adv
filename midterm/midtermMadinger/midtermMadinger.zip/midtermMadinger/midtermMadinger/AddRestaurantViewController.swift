//
//  AddRestaurantViewController.swift
//  midtermMadinger
//
//  Created by Dilara R Madinger on 3/20/18.
//  Copyright © 2018 Dilara R Madinger. All rights reserved.
//

import UIKit

class AddRestaurantViewController: UIViewController {
    @IBOutlet weak var nameTxtfield: UITextField!
    @IBOutlet weak var urlTxtfield: UITextField!
    var addedRest = String()
    var addedUrl = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        if segue.identifier == "doneSegue"{
            if((nameTxtfield.text?.isEmpty) == false){
                addedRest=nameTxtfield.text!
            }
            if((urlTxtfield.text?.isEmpty) == false){
                addedUrl=urlTxtfield.text!
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
